-- Creating the main database for the volleyball management system
-- CREATE DATABASE IF NOT EXISTS `volleyball_management_system` DEFAULT CHARACTER SET utf8;
CREATE DATABASE IF NOT EXISTS `volleyball_management_system`;

-- Set up the database we are working with
USE `volleyball_management_system`;

-- Create the admin table
CREATE TABLE IF NOT EXISTS `admins` (
  `admin_id` INT NOT NULL UNIQUE AUTO_INCREMENT,
  `admin_first_name` VARCHAR(100) NOT NULL,
  `admin_last_name` VARCHAR(100) NOT NULL,
  `admin_password` VARCHAR(100) NOT NULL,
  PRIMARY KEY(`admin_id`)
);

-- Create the championships table
CREATE TABLE IF NOT EXISTS `championships` (
  `championship_id` INT NOT NULL UNIQUE AUTO_INCREMENT,
  `championship_name` VARCHAR(100) NOT NULL UNIQUE,
  PRIMARY KEY(`championship_id`)
);

-- Create the teams table
CREATE TABLE IF NOT EXISTS `teams` (
  `team_id` INT NOT NULL UNIQUE AUTO_INCREMENT,
  `team_name` VARCHAR(100) NOT NULL,
  PRIMARY KEY(`team_id`)
);

-- Create players table
CREATE TABLE IF NOT EXISTS `players` (
  `player_id` INT NOT NULL UNIQUE AUTO_INCREMENT,
  `player_first_name` VARCHAR(100) NOT NULL,
  `player_last_name` VARCHAR(100) NOT NULL,
  `player_age` SMALLINT NOT NULL,
  `player_birth_day` DATETIME NOT NULL,
  PRIMARY KEY(`player_id`)
);

-- Create matches table
