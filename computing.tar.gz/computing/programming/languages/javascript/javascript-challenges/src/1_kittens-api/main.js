API_URL = "https://api.thecatapi.com/v1";
API_KEY = "live_8ocqLMnMCoYFZSg1a0HUSYk86snxvcjnedL6nSajjEUwDDhqiCaRcIRwfw2tzsYe";

const image = document.querySelector(".image-wrapper__image");
const buttonGet = document.querySelector(".controls__button-get");
const buttonFavorites = document.querySelector(".controls__button-favorites");
const buttonSaveFavorite = document.querySelector(".controls__button-save-favorite");
const currentImage = {};

async function getImage(currentImage) {
  const apiData = await fetch(`${API_URL}/images/search`);
  const jsonData = await apiData.json();

  const {id, url} = jsonData[0];

  currentImage["id"] = id;
  currentImage["url"] = url;
}

async function saveOrRemoveFromFavorites(currentImage) {
  if (buttonSaveFavorite.classList.contains("fa-regular")) {
    buttonSaveFavorite.classList.replace("fa-regular", "fa-solid");
    const res = await fetch(`${API_URL}/favourites`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": `${API_KEY}`
      },
      body: JSON.stringify(
        {
          "image_id": currentImage.id
        }
      )
    });
    console.log(res);

  } else {
    buttonSaveFavorite.classList.replace("fa-solid", "fa-regular");
  }
}

// await fetch(`https://api.thecatapi.com/v1/favourites/${favouriteId}`, requestOptions)
async function main() {
  await getImage(currentImage);
  image.src = currentImage.url

  buttonGet.addEventListener("click", async () => {
    await getImage(currentImage);
    image.src = currentImage.url
  });

  buttonSaveFavorite.addEventListener("click", async () => {
    await saveOrRemoveFromFavorites(currentImage);
  });
}

main();
