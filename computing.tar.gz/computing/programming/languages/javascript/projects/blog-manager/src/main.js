import app from "./server.js"
import mongoose from "mongoose"

const port = process.env.PORT ?? 5000
const host = process.env.HOST ?? "localhost"
const dbUri = process.env.MONGO_URI ?? "mongodb://mongo/myapp"


mongoose.connect(dbUri, {dbName: "blogapp"})
  .then(() => console.log("Connected!!!"))
  .catch((err) => console.log("Error connecting", err))

app.listen(port, () => {
  console.log(`App running at http://${host}:${port}`)
})