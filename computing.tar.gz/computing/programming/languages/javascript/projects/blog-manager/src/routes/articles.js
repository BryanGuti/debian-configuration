import express from "express"
import Article from "../models/articleModel.js"

const router = express.Router()

router.get("/", async (req, res) => {
  let articles = null
  articles = await Article.find().sort({createdAt: "desc"})
  res.render("pages/articles", { title: "Articles", articles})
})

router.get("/new", async (req, res) => {
  res.render("pages/createArticle", {article: new Article()})
})

router.get("/edit/:id", async (req, res) => {
  const article = await Article.findById(req.params.id)
  res.render("pages/editArticle", article)
})

router.get("/:slug", async (req, res) => {
  const article = await Article.findOne({slug: req.params.slug})
  if (!article) res.redirect("/articles")
  else res.render("pages/article", article)
})

router.post("/", async (req, res) => {
  let article = new Article({
    title: req.body.title,
    article: req.body.article,
    description: req.body.description
  })
  try {
    article = await article.save()
    res.redirect(`/articles/${article.slug}`)
  } catch (e) {
    res.render("pages/createArticle", { article })
  }
})

router.delete("/:id", async (req, res) => {
  await Article.findByIdAndDelete(req.params.id)
  res.redirect("/articles")
})

router.put("/:id", async (req, res) => {
  let article = {
    title: req.body.title,
    description: req.body.description,
    article: req.body.article
  }
  try {
    await Article.findByIdAndUpdate(req.params.id, article)
    article = await Article.findById(req.params.id)
    console.log(article)
    // article = await article.save()
    res.redirect(`/articles/${article.slug}`)
  } catch (e) {
    console.log(e)
    res.render("pages/editArticle", article)
  }

})

export default router