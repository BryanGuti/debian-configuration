import { join, dirname } from "node:path"
import { fileURLToPath } from "node:url"
import methodOverride from "method-override"
import express from "express"
import router from "./routes/articles.js"

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

const app = express()

app.set("view engine", "ejs")
app.set("views", join(__dirname, "views"))

app.use(express.urlencoded({ extended: false }))
app.use(methodOverride("_method"))

app.use("/articles", router)

app.get("/", (req, res) => {
  res.render("pages/home", {title: "Your Blog's home"})
})

export default app