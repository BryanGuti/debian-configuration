<?php
$page_title = "Global variables";
$heading = "Global varialbes";
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../styles/style.css">
  <title><?= $page_title ?></title>
</head>

<body>
  <div class="page">
    <header>
      <h1 class="heading"><?= $heading ?></h1>
    </header>
    <hr>
    <main>
      <article class="variable">
        <h2>$_SERVER</h2>
        <br>
        <?php foreach ($_SERVER as $key => $value): ?>
          <?php if (is_array($value)) continue ?>
          <p><?= "$key ==> $value" ?></p>
        <?php endforeach; ?>
      </article>
      <br>

      <article class="variable">
        <h2>$_REQUEST</h2>
        <br>
        <?php foreach ($_REQUEST as $key => $value): ?>
          <?php if (is_array($value)) continue ?>
          <p><?= "$key ==> $value" ?></p>
        <?php endforeach; ?>
      </article>
      <br>

      <article class="variable">
        <h2>$_ENV</h2>
        <br>
        <?php foreach ($_ENV as $key => $value): ?>
          <?php if (is_array($value)) continue ?>
          <p><?= "$key ==> $value" ?></p>
        <?php endforeach; ?>
      </article>
    </main>
    <div class="home-button"><a href="/" class="link">Back to home</a></div>
  </div>
</body>

</html>
