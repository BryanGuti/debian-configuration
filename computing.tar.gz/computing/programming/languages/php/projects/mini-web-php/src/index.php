<?php

$page_title = "PHP Concepts";
$heading = "PHP Concepts";

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./styles/style.css">
  <title><?= $page_title ?></title>
</head>

<body>
  <div class="page">
    <header>
      <h1 class="heading"><?= $heading ?></h1>
    </header>
    <hr>
    <main>
      <ul class="index">
        <li><a href="./pages/global-variables" class="link">Global Variables</a></li>
        <li><a href="./pages/arrays" class="link">Arrays</a></li>
        <li><a href="#" class="link">Link 3</a></li>
        <li><a href="#" class="link">Link 3</a></li>
      </ul>
    </main>
  </div>
</body>

</html>