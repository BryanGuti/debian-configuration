<?php

function sum($carry, $item)
{
  $carry += $item;
  return $carry;
}

$title = "Arrays";
$user_grades = [5.6, 3.5, 7.4, 6.8];
$average = (array_reduce($user_grades, "sum", 0) / count($user_grades));

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../styles/style.css">
  <title><?= $title ?></title>
</head>

<body>
  <div class="page">
    <header>
      <h1 class="heading">Arrays</h1>
    </header>
    <hr>
    <main>
      <article>
        <h2>Grades of student</h2>
        <br>
        <?php foreach ($user_grades as $key => $value): ?>
          <p class="grade"><?= "Grade $key => $value" ?></p>
        <?php endforeach; ?>
        <br>
        <p class="average"><?= "Average => $average" ?></p>
      </article>
    </main>
    <div class="home-button"><a href="/" class="link">Back to home</a></div>
  </div>
</body>

</html>
