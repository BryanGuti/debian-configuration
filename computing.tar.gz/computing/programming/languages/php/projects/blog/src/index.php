<?php

$title = "Bryan's Blog";
$name = "Platanito";
$age = 6;

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $title ?></title>
</head>

<body>
  <h1>Bryan's Blog</h1>
  <p>Learn all about computing!!!</p>
  <?php for ($i = 0; $i < 10; $i++): ?>
    <p>You are <?= $name ?></p>
  <?php endfor; ?>
  <?php if ($age >= 18): ?>
    <p>You are allowed to geting into the party!!!</p>
  <?php else: ?>
    <p>You cannot get into the party. Oh! No!</p>
  <?php endif; ?>
</body>

</html>