<?php

$text = "This is a long text";
$text_letters = explode(' ', $text);

foreach ($text_letters as $letter) {
  echo $letter . PHP_EOL;
}
