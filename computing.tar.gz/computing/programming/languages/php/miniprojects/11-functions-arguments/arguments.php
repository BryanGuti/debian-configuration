<?php

$name = "Bryan";
$age = 26;

// By value

function printGreeting($name = "unknown")
{
  echo "Hello {$name}" . PHP_EOL;
}

// By reference

function printAge(&$age = 18)
{
  echo "You are {$age} years old" . PHP_EOL;
  $age = 12;
  echo "You are {$age} years old" . PHP_EOL;
}

printGreeting($name);
echo $name . PHP_EOL;
printAge($age);
echo $age . PHP_EOL;
// printAge($age);
