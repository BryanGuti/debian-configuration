<?php

require __DIR__ . '/vendor/autoload.php';

// echo Text\Format::upperText("Hello my frontend friends!!!") . PHP_EOL;

echo upper("Hello my frontend friends!!!") . PHP_EOL;
echo upper("It's working!!!") . PHP_EOL;

echo lower("THIS FUNCTION IS WORKING!") . PHP_EOL;

$log = new Monolog\Logger('name');
$log->pushHandler(new Monolog\Handler\StreamHandler('app.log', Monolog\Level::Warning));
$log->warning('foo');
