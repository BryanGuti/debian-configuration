<?php

namespace Text;

class Format
{
  public static function upperText($text)
  {
    return strtoupper($text);
  }

  public static function lowerText($text)
  {
    return strtolower($text);
  }
}
