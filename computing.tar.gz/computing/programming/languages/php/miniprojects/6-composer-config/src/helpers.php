<?php

if (! function_exists("upper")) {
  function upper($text)
  {
    return Text\Format::upperText($text);
  }
}

if (! function_exists("lower")) {
  function lower($text)
  {
    return Text\Format::lowerText($text);
  }
}
