<?php

function addUser() {
  $user = 0;
  return Closure function() {
  };
}