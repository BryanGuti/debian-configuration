<?php

namespace App;

class Validate
{
  public static function email($email)
  {
    $pattern = "/^[\w]+@gmail.com$/";
    return (bool) preg_match($pattern, $email);
    // return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
  }

  public static function url($url)
  {
    $pattern = "/^(http(s)?:\/\/)?(www.)?[\w]{5,}.[a-zA-Z]{2,}$/";
    return (bool) preg_match($pattern, $url);
    // return (bool) filter_var($url, FILTER_VALIDATE_URL);
  }

  public static function password($password)
  {
    $pattern = "/^[\w]{9,}$/";
    return (bool) preg_match($pattern, $password);
  }
}
