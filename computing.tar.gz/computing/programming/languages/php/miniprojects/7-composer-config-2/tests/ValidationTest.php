<?php

use PHPUnit\Framework\TestCase;
use App\Validate;

class ValidationTest extends TestCase
{

  public function test_email()
  {
    $email = Validate::email("bryan@gmail.com");
    $this->assertTrue($email);

    $email = Validate::email("myemail@yahoo.com");
    $this->assertFalse($email);

    $email = Validate::email("myemail123GOOGLE@gmail.com");
    $this->assertTrue($email);

    $email = Validate::email("myemail123GOOGLE@@gmail.com");
    $this->assertFalse($email);
  }

  public function test_url()
  {
    $url = Validate::url("http://google.com");
    $this->assertTrue($url);

    $url = Validate::url("htt://google");
    $this->assertFalse($url);

    $url = Validate::url("http://www.google.");
    $this->assertFalse($url);

    $url = Validate::url("google.com");
    $this->assertTrue($url);

    $url = Validate::url("goo.com");
    $this->assertFalse($url);

    $url = Validate::url("google.c");
    $this->assertFalse($url);
  }

  public function test_password()
  {
    $password = Validate::password("niovwe23SAFF");
    $this->assertTrue($password);

    $password = Validate::password("niovwe23#SAFF");
    $this->assertFalse($password);

    $password = Validate::password("niovwe23");
    $this->assertFalse($password);

    $password = Validate::password("Sniovwe23");
    $this->assertTrue($password);

    $password = Validate::password("S@n_iovwe23");
    $this->assertFalse($password);
  }
}
