<?php

function printBanner($title = "Hello")
{
  $title_length = strlen($title);
  if ($title_length > 50) return;

  $width = ($title_length % 2) === 0
    ? 54
    : 53;

  echo PHP_EOL;
  echo "\t" . str_pad("", $width, "*") . PHP_EOL;
  echo "\t" . "*" . str_pad("", ($width - 2)) . "*" . PHP_EOL;
  echo "\t" . "*" . str_pad($title, ($width - 2), " ", STR_PAD_BOTH) . "*" . PHP_EOL;
  echo "\t" . "*" . str_pad("", ($width - 2)) . "*" . PHP_EOL;
  echo "\t" . str_pad("", $width, "*") . PHP_EOL;
}

function main()
{
  echo "\033[H" . "\033[2J";
  printBanner();
  printBanner("The best world's game");
  printBanner("Software development is top");
}

main();
