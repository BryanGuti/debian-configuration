<?php

$name = "Bryan David Gutierrez Alvarez";
$csv_programming_languages = "javascript,python,php,c,c++,typescript,bash scripting,rust,go,java,c#";
$users = ["Ana", "Jose", "Lucas", "Magdalena", "Sofia", "Luis", "Carlos"];
$text_with_html = "<script> console.log(\"This is a malicious script\") </script>";

// split text
// $letters = str_split($name);
// print_r($letters);


// get substring
// $first_name = substr($name, 0, 5);
// print_r($first_name . PHP_EOL);

// From string to array with separator
// $programming_languages = explode(",", $csv_programming_languages);
// print_r($programming_languages);

// From array to string with separator
// $csv_users = implode(",", $users);
// print_r($csv_users . PHP_EOL);

// Uppercase text
// $upper_name = strtoupper($name);
// print_r($upper_name . PHP_EOL);

// Lowercase text
// $lower_name = strtolower($name);
// print_r($lower_name . PHP_EOL);

// Lowercase first letter
// $lower_first_letter_name = lcfirst($upper_name);
// print_r($lower_first_letter_name . PHP_EOL);

// Uppercase first letter
// $upper_first_letter_name = ucfirst($lower_name);
// print_r($upper_first_letter_name  . PHP_EOL);

// Remove HTML tags
// $text_without_html_tags = strip_tags($text_with_html);
// print_r($text_without_html_tags . PHP_EOL);

// Multibyte ascii, utf, etc
// $text_without_multibyte = "Hola. Cómo están los niños?";
// print_r($text_without_multibyte . PHP_EOL);
// $text_with_multibyte = mb_substr($text_without_multibyte, 0, strlen($text_without_multibyte));
// print_r($text_with_multibyte . PHP_EOL);
