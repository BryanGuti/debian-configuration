#include <stdio.h>
#include <cs50.h>

int main(void)
{
  string name = get_string("What's your name? ");
  string last_name = get_string("What's your last name? ");
  string country = get_string("Where are you from? ");
  int age = get_int("How old are you? ");
  string ocupation = get_string("What do you do for a living? ");

  printf("Hello, %s %s!\n", name, last_name);
  printf("You are from %s\n", country);
  printf("You are %d years old\n", age);
  printf("You are a/an % s\n", ocupation);

  return 0;
}
