#! /usr/bin/env bash

# number_of_arguments="${#}"
source="${1}"
target="${2}"
backup=""

function verify_arguments() {
  if [[ ${#} -lt 2 ]]; then
    echo "Error: Missing arguments." >&2
    echo "Usage: ${0} <Source directory> <Target directory>"
    return 1
  fi

  return 0
}

function verify_directories() {
  if [[ ! -d "${source}" ]]; then
    echo "Error: '${source}' is not a valid directory" >&2
    return 1
  fi

  pushd "${source}" > /dev/null || \
  { echo "There was a problem at changing directory" >&2 && return 1; }
  source="$(pwd)"
  popd > /dev/null || \
  { echo "There was a problem at changing directory" >&2 && return 1; }

  backup="${target}/backup_$(date '+%Y-%m-%d_%H-%M-%S')"

  if [[ ! -d ${target} ]]; then
    echo "Creating '${backup}' backup directory"
    mkdir -p "${backup}"
  else
    echo "Renaming backup directory to ${backup}"
    mv "${target}/backup_"* "${backup}"
  fi

  pushd "${backup}" > /dev/null || \
  { echo "There was a problem at changing directory" >&2 && return 1; }
  backup="$(pwd)"
  popd > /dev/null || \
  { echo "There was a problem at changing directory" >&2 && return 1; }

  return 0
}

function back_up_files() {
  local source="${1}"
  local backup="${2}"
  local source_path=""
  local backup_path=""

  pushd "${source}" > /dev/null || \
  { echo "There was a problem at changing directory" >&2 && return 1; }

  for file in * .[^.]*; do

    [[ -e "${file}" ]] || continue

    source_path="${source}/${file}"
    backup_path="${backup}/${file}"

    if [[ ! -d "${file}" ]]; then
      if [[ "${file}" -nt "${backup_path}" ]];
      then
        echo "Backing up: '${source_path}' -> '${backup_path}'"
        cp "${source_path}" "${backup_path}"
      fi
      continue
    fi

    if [[ "${file}" -nt "${backup_path}" ]];
    then
      mkdir -p "${backup_path}"
      back_up_files "${source_path}" "${backup_path}"
    fi
  done

  popd > /dev/null || \
  { echo "There was a problem at changing directory" >&2 && return 1; }

  return 0
}

function main() {
  if ! verify_arguments "${@}"; then exit 1; fi
  if ! verify_directories; then exit 1; fi
  if ! back_up_files "${source}" "${backup}"; then exit 1; fi

}

main "${@}"