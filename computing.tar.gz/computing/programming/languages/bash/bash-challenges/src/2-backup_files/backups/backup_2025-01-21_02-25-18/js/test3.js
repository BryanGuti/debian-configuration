function main() {
	console.log("Hello, world!");
}

main();
