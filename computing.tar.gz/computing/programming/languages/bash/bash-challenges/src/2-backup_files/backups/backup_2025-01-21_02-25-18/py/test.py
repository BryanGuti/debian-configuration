print("Hello, world!")

print("Welcome to programming world!")
