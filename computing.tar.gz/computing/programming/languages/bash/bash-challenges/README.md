# Bash scripting challenges
