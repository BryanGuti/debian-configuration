#include <iostream>
#include <string>
#include <unistd.h>

using namespace std;

class Pokemon
{

private:
  string name;
  uint16_t score = 0;
  int8_t health = 100; // Fixed typo
  uint8_t damage;
  bool isAttacking = false;

  Pokemon &setScore()
  {
    this->score += (this->damage * 2);
    return *this;
  }

  Pokemon &attack(Pokemon &pokemon)
  {
    pokemon.setHealth(this->damage);
    return *this;
  }

public:
  static uint16_t numberOfPokemons;

  Pokemon(string name, uint8_t damage) : name(name), damage(damage)
  {
    Pokemon::numberOfPokemons++;
  }

  ~Pokemon()
  {
    cout << "The pokemon " << this->name << " was deleted successfully" << endl;
  }

  Pokemon &setHealth(uint8_t damage)
  {
    if (this->isAttacking)
    {
      this->health += 2;
      this->isAttacking = false;
    }
    else
    {
      this->health -= damage;
      this->isAttacking = true;
    }
    return *this; // Fixed missing return statement
  }

  string getName()
  {
    return this->name;
  }

  void restorHealth()
  {
    this->health = 100;
  }

  void fight(Pokemon &pokemon)
  {

    this->isAttacking = true;
    this->attack(pokemon).setScore().setHealth(this->damage);

    cout << this->name << endl;
    cout << "Score: " << +this->score << endl;
    cout << "Health: " << +this->health << endl;
    cout << endl;

    sleep(1);

    if (this->health <= 0)
    {
      cout << this->name << " has lost" << endl;
      cout << pokemon.getName() << " has win" << endl;
      cout << endl;
      this->health = 100;
      pokemon.restorHealth();
      sleep(2);
      return;
    }

    pokemon.fight(*this);
  }
};

uint16_t Pokemon::numberOfPokemons = 0;

int main()
{
  Pokemon *pikachu = new Pokemon("Pikachu", 20);
  Pokemon *charizard = new Pokemon("Charizard", 23);
  Pokemon *snorlock = new Pokemon("Snorlock", 22);

  cout << "There are " << +Pokemon::numberOfPokemons << " pokemons created" << endl;
  cout << endl;

  sleep(2);

  cout << "\033[H" << "\033[2J" << endl;
  cout << "First fight" << endl;
  cout << endl;
  pikachu->fight(*charizard);

  cout << "\033[H" << "\033[2J" << endl;
  cout << "Second fight" << endl;
  cout << endl;
  snorlock->fight(*pikachu);

  delete pikachu;
  delete charizard;
  delete snorlock;

  return 0;
}