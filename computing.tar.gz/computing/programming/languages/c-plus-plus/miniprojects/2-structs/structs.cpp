#include <iostream>
#include <string>

using namespace std;

struct Usuario
{
  string name;
  uint8_t age;
};

int main()
{
  Usuario persona = Usuario();
  persona.name = "Bryan David Gutierrez Alvarez";
  persona.age = 26;

  cout << "Hi! " << persona.name << ". You are " << +persona.age << " years old" << endl;

  return 0;
}