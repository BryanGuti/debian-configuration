#include <iostream>

using namespace std;

union number_letter
{
  int number;
  char letter;
};

int main()
{
  number_letter nl = {64};

  cout << "nl as number: " << nl.number << endl;
  cout << "nl as letter: " << nl.letter << endl;

  return 0;
}