#include <iostream>

using namespace std;

class Person
{
  string name;
  uint8_t age;

public:
  void setAge(uint8_t age)
  {
    this->age = age;
    cout << "The age is: " << +age << endl;
  }

  void setName(string name)
  {
    this->name = name;
    cout << "The name is: " << this->name << endl;
  }
};

int main()
{
  Person person = Person();
  cout << "Person 1" << endl;
  person.setName("Jorge");
  (&person)->setAge(11);
  person.setAge(26);

  cout << endl;

  Person *person2 = new Person();
  cout << "Person 2" << endl;
  person2->setName("Sebastian");
  (*person2).setAge(44);
  person2->setAge(18);

  delete person2;

  return 0;
}