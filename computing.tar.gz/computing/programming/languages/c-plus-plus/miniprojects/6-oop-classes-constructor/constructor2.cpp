#include <iostream>

using namespace std;

class User
{
private:
  string name;
  string email;
  uint8_t age;

public:
  // User's constructor. Different way
  User(string name, string email, uint8_t age) : name(name), email(email), age(age) {}
  // User's destructor
  ~User()
  {
    cout << "The user " << this->name << " was deleted successfully" << endl;
  }

  void getInformation()
  {
    cout << "Name: " << this->name << endl;
    cout << "Email: " << this->email << endl;
    cout << "Age: " << +this->age << endl;
    cout << endl;
  }
};

int main()
{
  User *user1 = new User("Lola Mento", "lola@mento.com", 23);
  User *user2 = new User("Jorge Nitales", "jorge@nitales.com", 50);
  User *user3 = new User("Monica Galindo", "monica@galindo.com", 44);

  user1->getInformation();
  user2->getInformation();
  user3->getInformation();

  delete user1;
  delete user2;
  delete user3;

  return 0;
}