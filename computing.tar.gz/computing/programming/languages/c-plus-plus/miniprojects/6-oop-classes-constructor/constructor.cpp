#include <iostream>

using namespace std;

class Triangle
{
private:
  uint32_t base;
  uint32_t height;

public:
  // Object's constructor
  Triangle(uint32_t base, uint32_t height)
  {
    this->base = base;
    this->height = height;
  }

  // Object's destructor
  ~Triangle()
  {
    cout << "The object with base " << +this->base << " and heigth " << +this->height << " was deleted" << endl;
  }

  void getArea()
  {
    double area = (double)(this->base * this->height) / 2;
    cout << "The area is: " << area << endl;
  }
};

int main()
{
  Triangle *triangle = new Triangle(22, 10);
  cout << "Triangle 1" << endl;
  triangle->getArea();
  delete triangle;

  cout << endl;

  Triangle *triangle2 = new Triangle(5, 4);
  cout << "Triangle 2" << endl;
  triangle2->getArea();
  delete triangle2;

  return 0;
}