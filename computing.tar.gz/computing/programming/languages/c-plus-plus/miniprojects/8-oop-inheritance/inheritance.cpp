#include <iostream>

using namespace std;

class Shape
{

public:
  Shape();
  ~Shape();
  static uint16_t numberOfShapes;
};

uint16_t Shape::numberOfShapes = 0;

Shape::Shape()
{
  Shape::numberOfShapes++;
}

Shape::~Shape()
{
  Shape::numberOfShapes--;
  printf("\nThe Shape has been deleted\n");
}

class Triangle : Shape
{
private:
  double base;
  double height;

public:
  Triangle(double base, double height);
  ~Triangle();

  double getArea();
};

Triangle::Triangle(double base, double height)
{
  this->base = base;
  this->height = height;
}

Triangle::~Triangle()
{
  printf("\nTriangle with base %.2f and height %.2f has been deleted\n", this->base, this->height);
}

double Triangle::getArea()
{
  return (this->base * this->height) / 2;
}

int main()
{
  printf("\nThere are %d shapes\n", Shape::numberOfShapes);

  Triangle *triangle = new Triangle(11.3, 5.5);
  printf("\nThere are %d shapes\n", Shape::numberOfShapes);
  printf("\nThe area is: %.2f\n", triangle->getArea());

  delete triangle;
  printf("\nThere are %d shapes\n", Shape::numberOfShapes);

  return 0;
}