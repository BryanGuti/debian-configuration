#include <iostream>

using namespace std;

int main()
{
  char first_letter_name = 'B';
  char *pointer = &first_letter_name;

  cout << "The first_letter_name value is: " << first_letter_name << endl;
  cout << "The firs_letter_name memory direction is: " << (int *)&first_letter_name << endl;

  cout << "The pointer value is: " << (int *)pointer << endl;
  cout << "The pointer memory direction is: " << (int *)&pointer << endl;
  cout << "The pointer dereferenced value is: " << *pointer << endl;

  return 0;
}