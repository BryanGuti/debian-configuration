#include <iostream>

using namespace std;

int main()
{
  char name[] = "Juan Jose Almada";

  char *pointer = name;

  int i = 0;

  printf("Your name is: ");
  while (*(pointer + i) != '\0')
  {
    printf("%c", *(pointer + i));
    i++;
  }

  printf("\n");
  // printf("Your name is: %c", *pointer);

  return 0;
}