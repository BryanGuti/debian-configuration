#include <iostream>

using namespace std;

enum rgb
{
  red = 'r',
  green = 'g',
  blue = 'b'
};

int main()
{
  rgb led_color = red;

  cout << "You have choice the color ";

  switch (led_color)
  {
  case 'r':
    cout << "red";
    break;
  case 'g':
    cout << "green";
    break;
  case 'b':
    cout << "blue";
    break;
  default:
    cout << "unknown";
    break;
  }

  cout << endl;

  return 0;
}