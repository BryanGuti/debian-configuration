﻿class Program
{
  static void printLayout()
  {
    Console.Clear();
    Console.WriteLine("\n");
    Console.WriteLine("\t*********************************");
    Console.WriteLine("\t**          FIBONACCI          **");
    Console.WriteLine("\t*********************************");
    Console.WriteLine("\n");
  }

  static void printMenu()
  {
    Console.WriteLine("\tChoose one of the options below.\n");
    Console.WriteLine("\t1. Print the Fibonacci serie to N.");
    Console.WriteLine("\t2. Print the first N numbers of the Fibonacci serie.");
    Console.WriteLine("\t3. Exit");
    Console.WriteLine();
  }
  static void Main(string[] args)
  {
    printLayout();
    printMenu();
    Console.ReadKey(true);
    // Console.WriteLine("Fibonacci is working!");
  }
}
