import click


@click.group()
@click.pass_context
def product(ctx):
    pass
