import click


@click.group()
@click.pass_context
def user(ctx):
    pass
