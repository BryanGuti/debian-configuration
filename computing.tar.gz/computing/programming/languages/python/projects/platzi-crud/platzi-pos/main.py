import click
from src.users.user import user
from src.products.product import product


@click.group()
@click.pass_context
def cli(ctx):
    pass


cli.add_command(user)
cli.add_command(product)


if __name__ == '__main__':
    cli()
