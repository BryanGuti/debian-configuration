def main():
  name : str = input("Type your name: ")
  print(f"Hello, {name}. This is your first Python's program!")

if __name__ == '__main__':
  main()
